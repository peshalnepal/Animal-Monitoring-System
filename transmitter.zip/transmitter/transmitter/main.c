#define  F_CPU 2000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#define  BAUD_RATE 9600
#define baude_prescale ((F_CPU/(BAUD_RATE*16UL))-1)
char datasend[3]={0x41,0x42,0x0A};
int checksum=0;
void send(void);
void sumcheck(void);
void installling(void);
int main(void)
{
	installling();
	
    while (1) 
    {
        checksum=0;
		send();
		sumcheck();
    }
}

void send()
{
	for(uint8_t i=0;i<3;i++)
	{
		 while (!(UCSRA&(1<<UDRE)));
		 UDR=datasend[i];
		 checksum =checksum+datasend[i];
	}
	
}
void sumcheck()
{
	char tempr[5];
	itoa(checksum,tempr,10);
for (uint8_t i=0;i<5;i++)
{
	while (!(UCSRA&(1<<UDRE)));
	UDR=tempr[i];
}
	
}
void installling()
{
	UBRRH=baude_prescale>>8;
	UBRRL=baude_prescale;
	UCSRC|=(1<<URSEL)|(3<<UCSZ0);
	UCSRB|=(1<<TXEN)|(1<<RXEN);
}